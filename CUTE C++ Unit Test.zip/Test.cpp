#include "cute.h"
#include "ide_listener.h"
#include "cute_runner.h"


void test_1() {
	ASSERT_EQUAL(0, 0);
}

void runSuite(){
	cute::suite s;
	s.push_back(CUTE(test_1));
	cute::ide_listener<> lis;
	cute::makeRunner(lis)(s, "CUTE Example");
}

int main(){
    runSuite();
    return 0;
}
